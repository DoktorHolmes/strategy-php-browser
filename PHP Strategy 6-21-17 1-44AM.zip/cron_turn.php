<?php
/*   ________________________________________________
    |    Converted by YAK Pro - mysql to mysqli      |
    |  GitHub: https://github.com/pk-fr/yakpro-mtm   |
    |________________________________________________|
*/

include 'functions.php';
$link = connect();
// Turns every 30 minutes
$get_users = mysqli_query($link, 'SELECT * FROM `stats`') or die(mysqli_error($link));
while ($user = mysqli_fetch_assoc($get_users)) {
    $update = mysqli_query($link, 'UPDATE `stats` SET
                            `gold`=`gold`+\'' . $user['income'] . '\',
                            `food`=`food`+\'' . $user['farming'] . '\',
                            `turns`=`turns`+\'5\' WHERE `id`=\'' . $user['id'] . '\'') or die(mysqli_error($link));
}
?>
