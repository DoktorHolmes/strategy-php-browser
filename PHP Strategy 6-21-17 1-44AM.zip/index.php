<?php
session_start();
include("header.php");

include("footer.php");
?>