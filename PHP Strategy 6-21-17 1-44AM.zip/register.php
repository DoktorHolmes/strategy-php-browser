<?php
/*   ________________________________________________
    |    Converted by YAK Pro - mysql to mysqli      |
    |  GitHub: https://github.com/pk-fr/yakpro-mtm   |
    |________________________________________________|
*/

session_start();
include 'header.php';
?>
Register
<br /><br />
<?php 
if (isset($_POST['register'])) {
    $username = protect($_POST['username']);
    $password = protect($_POST['password']);
    $email = protect($_POST['email']);
    if ($username == '' || $password == '' || $email == '') {
        echo 'Please supply all fields!';
    } elseif (strlen($username) > 20) {
        echo 'Username must be less than 20 characters!';
    } elseif (strlen($email) > 100) {
        echo 'E-mail must be less than 100 characters!';
    } else {
        $register1 = mysqli_query($link, "SELECT `id` FROM `user` WHERE `username`='{$username}'") or die(mysqli_error($link));
        $register2 = mysqli_query($link, "SELECT `id` FROM `user` WHERE `email`='{$email}'") or die(mysqli_error($link));
        if (mysqli_num_rows($register1) > 0) {
            echo 'That username is already in use!';
        } elseif (mysqli_num_rows($register2) > 0) {
            echo 'That e-mail address is already in use!';
        } else {
            $ins1 = mysqli_query($link, 'INSERT INTO `stats` (`gold`,`attack`,`defense`,`food`,`income`,`farming`,`turns`) VALUES (100,10,10,100,10,11,100)') or die(mysqli_error($link));
            $ins2 = mysqli_query($link, 'INSERT INTO `unit` (`worker`,`farmer`,`warrior`,`defender`) VALUES (5,5,0,0)') or die(mysqli_error($link));
            $ins3 = mysqli_query($link, "INSERT INTO `user` (`username`,`password`,`email`) VALUES ('{$username}','" . md5($password) . "','{$email}')") or die(mysqli_error($link));
            $ins4 = mysqli_query($link, 'INSERT INTO `weapon` (`sword`,`shield`) VALUES (0,0)') or die(mysqli_error($link));
            $ins5 = mysqli_query($link, 'INSERT INTO `ranking` (`attack`,`defense`,`overall`) VALUES(0,0,0)') or die(mysqli_error($link));
            echo 'You have registered!';
        }
    }
}
?>
<br /><br />
<form action="register.php" method="POST">
Username: <input type="text" name="username"/><br />
Password: <input type="password" name="password"/><br />
E-mail: <input type="text" name="email"/><br />
<input type="submit" name="register" value="Register"/>
</form>
<?php 
include 'footer.php';
?>
