<?php
/*   ________________________________________________
    |    Converted by YAK Pro - mysql to mysqli      |
    |  GitHub: https://github.com/pk-fr/yakpro-mtm   |
    |________________________________________________|
*/
if (!function_exists('connect')) {
	function connect()
	{
	
		$link=mysqli_connect('0.0.0.0', 'root', 'victorpass', 'game');
		return $link;
	}
}
if (!function_exists('protect')) {
	function protect($string)
	{
		$link = connect();
		return mysqli_real_escape_string($link, strip_tags(addslashes($string)));
	}
}
if (!function_exists('output')) {
	function output($string)
	{
		echo '<div id="output">' . $string . '</div>';
	}
}
?>
